package com.example.hw6q2

import android.app.AlertDialog
import android.graphics.Color
import android.os.Bundle
import android.view.LayoutInflater
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.OnMapReadyCallback
import com.google.android.gms.maps.SupportMapFragment
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.PolygonOptions
import com.google.android.gms.maps.model.PolylineOptions

class MainActivity : AppCompatActivity(), OnMapReadyCallback {

    private lateinit var mMap: GoogleMap
    private var hikingTrailPolyline: com.google.android.gms.maps.model.Polyline? = null
    private var areaPolygon: com.google.android.gms.maps.model.Polygon? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val mapFragment =
            supportFragmentManager.findFragmentById(R.id.map) as SupportMapFragment
        mapFragment.getMapAsync(this)
    }

    override fun onMapReady(googleMap: GoogleMap) {
        mMap = googleMap

        // Add polyline representing a hiking trail
        val trailCoordinates = listOf(
            LatLng(37.4219999, -122.0840575),
            LatLng(37.4220, -122.0850),
            LatLng(37.4230, -122.0860)
        )
        hikingTrailPolyline = mMap.addPolyline(
            PolylineOptions()
                .addAll(trailCoordinates)
                .color(Color.BLUE)
                .width(10f)
                .clickable(true)
        )

        // Add polygon representing a park/area
        val parkCoordinates = listOf(
            LatLng(37.424, -122.082),
            LatLng(37.424, -122.083),
            LatLng(37.425, -122.083),
            LatLng(37.425, -122.082)
        )
        areaPolygon = mMap.addPolygon(
            PolygonOptions()
                .addAll(parkCoordinates)
                .strokeColor(Color.RED)
                .fillColor(Color.argb(70, 150, 50, 50))
                .strokeWidth(5f)
                .clickable(true)
        )

        // Set click listeners for overlays
        mMap.setOnPolylineClickListener { polyline ->
            Toast.makeText(this, "Trail clicked", Toast.LENGTH_SHORT).show()
            showCustomizationDialog(isPolyline = true)
        }

        mMap.setOnPolygonClickListener { polygon ->
            Toast.makeText(this, "Area clicked", Toast.LENGTH_SHORT).show()
            showCustomizationDialog(isPolyline = false)
        }

        // Move camera to show the overlays
        mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(LatLng(37.422, -122.084), 15f))
    }

    private fun showCustomizationDialog(isPolyline: Boolean) {
        val dialogView = LayoutInflater.from(this).inflate(R.layout.dialog_customization, null)
        val etColor = dialogView.findViewById<EditText>(R.id.etColor)
        val etWidth = dialogView.findViewById<EditText>(R.id.etWidth)

        AlertDialog.Builder(this)
            .setTitle(if (isPolyline) "Customize Trail" else "Customize Area")
            .setView(dialogView)
            .setPositiveButton("Apply") { dialog, _ ->
                val colorInput = etColor.text.toString()
                val widthInput = etWidth.text.toString()
                try {
                    val newColor = Color.parseColor(colorInput)
                    val newWidth = widthInput.toFloat()
                    if (isPolyline && hikingTrailPolyline != null) {
                        hikingTrailPolyline?.color = newColor
                        hikingTrailPolyline?.width = newWidth
                    } else if (!isPolyline && areaPolygon != null) {
                        areaPolygon?.strokeColor = newColor
                        areaPolygon?.strokeWidth = newWidth
                        // Optionally update fill color based on new color:
                        areaPolygon?.fillColor =
                            Color.argb(70, Color.red(newColor), Color.green(newColor), Color.blue(newColor))
                    }
                } catch (e: Exception) {
                    Toast.makeText(this, "Invalid input", Toast.LENGTH_SHORT).show()
                }
                dialog.dismiss()
            }
            .setNegativeButton("Cancel") { dialog, _ -> dialog.dismiss() }
            .create()
            .show()
    }
}
